<?php
require(ROOT . "Config/db.php");
require(ROOT . "Core/Model.php");
require(ROOT . "Core/Controller.php");
